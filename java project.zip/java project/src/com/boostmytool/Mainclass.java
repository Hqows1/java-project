package com.boostmytool;

public class Mainclass {
    public static void main(String[] args){
        System.out.println("Hello world ...");
    }
}
